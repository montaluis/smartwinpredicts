 <?php
    session_start();
    include('../connection/connection.php');

    
if(!isset($_SESSION['email'])){
    header("location: login.php");
}
else {

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- bootstrap link -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../icons/css/all.min.css">

    <!-- Owl carousel --> 
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- AOS link --> 
    <link rel="stylesheet" href="../aos-master/dist/aos.css">
 

    <title>Smart-win| Personal info</title>

     <style>
     @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Roboto:ital@1&display=swap'); 
  *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Poppins', sans-serif;
      
  }
  
  body{ 
      background:black;
      color:white;
      margin:0;
      padding:0;
      max-width:100vw;
      box-sizing:border-box;
      overflow-x:hidden;
  }
     .top-header{
         background:rgb(6, 2, 34);
         display:flex; 
         justify-content:space-between;
         align-items:center;
         text-align:center; 
         width:100%;
         z-index:1111;
     }   
     .top-header .top h2{
         color:green;
         padding:.5rem .5rem;
         font-weight:700;
         font-size:25px;
        font-family: 'Poppins', sans-serif;
     }
     .top-header .top span{
         color:yellow;
     }
     
     .top-header .top p{
         color:white;
         padding-left:.5rem;
         position:relative;
         margin-top:-1rem;
     }
     
     .top-header .header{
    position:relative;
    display: flex; 
  } 
  
  header .user_img {
      display:flex; 
      padding:1vh 0; 
      position:relative;
      right:2vw;
  }
  
  header .user_img img{
      margin-right:1vw;
  }
   
   header .user_img p{
       margin-right:1vw;
       padding-top:1vh;
   }
   
   header .nav{
       padding:1vh 1vw;
   }
   
   header .nav a{
       color:white;
       font-weight:600;
   }
   
   header .nav a:hover{
       color:green;
   }
   
   header #menu{
       display:none;
   }
   
   .main .card{
       display:flex;
       border-radius:2rem;
       border:3px solid #9fcc2e;
       background:#0E402D;
       margin:1vh 2vw;
       padding:1vh 2vw;
       line-height:2px;
       
   }
   
   .main .card img{
       position:relative;
       top:2vh;
       border-radius:50%;
   }
   
   .main .card .amt{
       display:flex;
       position:relative;
       top:-6vh;
       left:8vw;
   }
   #noti_number2{
       font-weight:900;
       position:relative;
       top:-2vh;
       margin-left:1vw;
   }
   .main .card .n{
       font-weight:800; 
       font-size:25px;
       position:relative; 
       left:8vw;
       top:-8vh;
       text-transform:capitalize;
   }
   
   .main .b{
       color:#ffb400;
   }
   
   .main .b a{
        color:#ffb400;
   }
   
   .main h3{
       text-align:center;
       margin:2vh 0;
       font-weight:600;
   }
    
    
    .side1 .q{
       background:#0E402D;
       padding:1vh 1vw;
       margin:2vh 0;
       border-radius:1rem;
    }
    
    .side1 .st{
       background:#0E402D;
       padding:1vh 1vw;
       margin:2vh 0;
       border-radius:1rem; 
    }
    
    .side2 .l{
       background:#0E402D;
       padding:1vh;
       margin:2vh 0;
       border-radius:1rem;
    }
    
    .title-box{
    margin: 15px 0;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap; 
    align-items: center;
    justify-content:center;
    width: 100%;
    font-size: 1.5em;
   
    
}
.title-box #goals{
    font-size: 25px; 
    padding: .5rem;
}
.team{
    width: 100px;
}
.team img{
    height: 54px;
    width: 54px;
}
.matches-table{
    margin-top: 50px;
    display: flex;
    flex-direction: column;
}
.match-tile{
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    margin: 10px 0;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    
}
.match-tile img{
    width: 52px;
    height: 52px;
}
.match-tile p{
    font-size: 1.2rem;
}

.match-tile #goals{
    font-size: 1.8rem;
}
.match-tile .team{
    width: 100px;
}

 #btn{
        background:#0E402D;
        padding:.5rem 2rem; 
        font-weight:bolder;
        border:none;
        outline:none;
        border-radius:3rem;
        color:#fff;
    } 
     
     input[type='email'],
    input[type='text']{
        color:white;
        outline:none;
        background:transparent;
        border:none;
        border-bottom:2px solid #0E402D ;
        margin-top:3vh;
        width:100%; 
    }
    textarea{
        color:white;
        outline:none;
        background:transparent;
        border:none;
        border-bottom:2px solid #0E402D ;
        margin-top:3vh;
        width:100%; 
        height:20vh !important;
    }

    
@media only screen and (max-width:500px){
 
 body{
     overflow-x:hidden;
 }
 
  header #menu{
     display:flex;
     position:relative;
    margin-right:2vw;
 }
 
 header .nav {
     display:none;
 }
 
 header .user_img {
     display:none;
 }
 
 header .offcanvas-body{
     background:black;
     color:#fff !important;
 }
 
 header .offcanvas-body a{
     color:white;
     text-decoration:none;
 }
 
 header .offcanvas-body li a:hover{
     color:#0E402D;
     font-weight:bolder;
 }
 
 header .offcanvas-body li{
     list-style-type:none;
 }
 
 header .offcanvas-body form button{
     background: #0E402D;
     padding:1rem 3rem;
     color:#fff;
     border-radius:3rem;
     border: none;
     outline:none;
 }
 
 header .offcanvas-header{
     background:#0E402D;
 }

header .offcancas-header button{
    color:#fff !important;
}

.statistics{
    display:none;
}
   .main{
       margin:0 !important;
       box-shadow:none !important;
       padding:0 1rem;
   }
   
 .main .card{ 
     max-width:98vw; 
     padding:2vw;
     border-radius:1rem;
 }
 .main .card img{
     width:70px !important;
     height:70px !important;
 }
 
 .main .card .amt{
       display:flex;
       position:relative;
       top:-5.5vh;
       left:24vw;
   }
 
  #noti_number2{
       font-weight:900;
       position:relative;
       top:-2vh;
       margin-left:1vw;
   }
   .main .card .n{
       font-weight:600; 
       font-size:20px;
       position:relative; 
       left:24vw;
       top:-8vh;
       text-transform:capitalize;
   }
   .main .card .btn-success{
       margin-top:-4vh !important;
   }
   
   .main img{
       width:50px;
       height:50px;
   }
   
   .main .b{
       position:relative;
       padding:3vw; 
       word-wrap: break-word; 
   }
   .main p{
       font-size:14px;
   }
   .main .b a{
       word-wrap: break-word;
       font-size:11px;
   }
   
   footer{
       font-size:8px;
       position:fixed;
   }
    
   .top-header{
       display:flex;
       box-shadow:0 0 0 rgb(0,0,0);
   }
   
   .top-header h1{
       margin-top:-2rem;
   }
   
    .top-header img{ 
        width:100px;
        height:100px; 
        margin-bottom:-2rem;
        margin-top:-3rem;
        
    } 
    
    .top-header span{
        margin-top:1rem;
        font-size:25px;
        font-weight:500px;
        height:30px;
    }
    
   
.top-header .header{
    position:relative;
    display: flex; 
  }
  
  .win{
      font-size:10px;
  }
  h3{
      font-size:15px;
  }
  .side1{
      display:none;
  }
  .nav{ 
  }
 .user_img h4{  
     margin-top:-2rem;
  }
    .user_img img{
    float:left; 
     width:80px;
     height:80px;
    position: relative;
    margin-top:-2rem;
    margin-left:1rem;
    }
    
     .depo{
        text-align:center;
    }
    
    .user_img{
        margin-top:-2rem;
    }
     
   .side2{
       display:none;
   }
} 

    </style>
</head>
<body>
        <header class="top-header" id="myHeader">
            <div class="top">
            <h2>Smart<span>Win</span></h2>
                <p>Real Football Predicts</p>
            </div> 
            
        <div id="menu">
            <button class="btn btn-success" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                <i class="fa fa-bars"></i>
            </button>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Menu</h5>
    <button type="button" class="btn-close text-reset" style="margin-right:9vw;color:white !important;" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body" align="left">
      <div>
          <ul>
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../pages/home.php">My Profile</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../links/personal_info.php">Personal Info</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../links/account_setting.php">Account Setting</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../play/QS.php">Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="plan.php">Account History</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../links/my_referrals.php">My Referral</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="plan.php">Payment Plan</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="how.php">How To Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="rule.php">Rules</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact us</a>
                          </li>
          </ul>
      </div>
    <div>
      <div class="form">
          <form action="#" method="post">
              <button name="logout"><i class="fa fa-power-off" aria-hidden="true"></i>
              </button>
              <?php
        
                if(isset($_POST['logout'])){

                    $user = $_SESSION['email'];
                    $get_user = "select * from users where email='$user'";
                    $run_user = mysqli_query($link, $get_user);
                    $row = mysqli_fetch_array($run_user);

                    $user_id = $row['user_id'];
                    $user_name = $row['firstname'];
                    $Lastname = $row['lastname'];
                    $sex = $row['status']; 
                    $user_profile = $row['user_pics']; 


                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                    echo"<script>window.open('../pages/login.php', '_self')</script>";
                    exit();
                }

            ?>
          </form>
      </div>
    </div> 
  </div>
</div>
                
                </div>
                    <div class="nav"> 
                        <ul class="nav justify-content-center"> 
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="plan.php">Payment Plan</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="how.php">How To Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="rule.php">Rules</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact us</a>
                          </li>
                        </ul> 
                    </div> 
                        <div class="user_img "> 
                        <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $user_name = $row['firstname'];
                        $Lastname = $row['lastname'];
                        $sex = $row['status']; 
                        $user_profile = $row['user_pics'];
                        
                        $get_amount = "select * from users where email='$user'";
                        $run_amount = mysqli_query($link, $get_amount);
                        $row_user = mysqli_fetch_array($run_amount);

                        $id = $row_user[' id'];
                        $amount = $row_user['available_bal' ]; 
                    ?>
                  <div class="d-inline-flex text-light">
                    <div class="right-header-img">
                        <img src="<?php echo "$user_profile";?>" width="40px" height="40px"style="border-radius:50%;border:1px solid green;">
                    </div>  
                        <p><strong><?php echo"$user_name $Lastname"?></strong></p>  
                            <form action="" method="post">
                            <button name="logout" width="10px" class="btn text-center text-light"><i class="fa fa-power-off"></i></button>

                            <?php
                                 
                                if(isset($_POST['logout'])){
                                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                                    echo"<script>window.open('login.php', '_self')</script>";
                                    exit();
                                }

                                ?>
                            </form>  
                    </div>
                </div>
            </div> 
        </header>
        <div class="row d-flex">
            <div class="col-md-3 col-sm-4 col-xs-12 side1">
                <div class="statistics">
                        <div class="header-statistics">
                            <div class="theme">
                            <div class='st mx-2' align='center'>
                                <h3 class='text-center'><strong>Quick Links</strong></h3>
                                <ul class='text-left'style='list-style-type:none;padding-right:1.5rem;'>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../pages/home.php" style="color:white !important;"><i class="fa fa-user-circle" aria-hidden="true"></i> My Profile</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="personal_info.php" class="active" style="color:white !important;"><i class="fa fa-address-book" aria-hidden="true"></i> Personal Info</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="account_setting.php" style="color:white !important;"><i class="fa fa-cogs" aria-hidden="true"></i> Account Setting</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../play/QS.php" style="color:white !important;"><i class="fa fa-futbol" aria-hidden="true"></i> Play</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="#" style="color:white !important;"><i class="fa fa-database" aria-hidden="true"></i> Account History</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="my_referrals.php" style="color:white !important;"><i class="fa fa-users" aria-hidden="true"></i> My Referrals</a></h5></li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        <?php
                        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                        $total_messages = "select * from users";
                        $run_messages = mysqli_query($link, $total_messages);
                        $total = mysqli_num_rows($run_messages);

                        $online_members = "select * from users where status='Online'";
                        $run_online = mysqli_query($link, $online_members);
                        $sum = mysqli_num_rows($run_online);?>
                                  
             <?php 
                       $selects = "SELECT SUM(total_withdraw) AS sum FROM `withdraw_request` where status='paid'";
                       $pick = mysqli_query( $link, $selects);
                       
     while($row = mysqli_fetch_assoc($pick)){
         $paid= $row['sum'];
     }
                  
                        
                  
                      ?>
                        <?php
                           
                           $date =date("Y-m-d");
                           echo"<div class='text-center text-light'>$date</div>";
                           $today_members = "select * from users where date='$date'";
                        $run_today = mysqli_query($link, $today_members);
                        $today = mysqli_num_rows($run_today);

                        ?>
                        <?php
                        echo "<div class='q mx-2' style='box-shadow:
                        3px 4px 10px rgba(225,225,225,0.567);' align='center'>
                        <h3 class='text-center'><strong>STATISTICS</strong></h3>
                        <ul class='text-center d-flex'style='list-style-type:none;padding-right:1.5rem; color: yellow;'>
                                <li><p>  $total </p><small>Total Members</small></li>
                                <li><p>$today</p><small>Joined Today</small></li>
                                <li><p> $sum </p><small>Online Members</small></li>
                                <li><p>$paid</p><small>Total Payments</small></li>
                            </ul>
                        </div>";
                        ?>  
                    </div>
            </div> 
            <div class="col-md-6 main" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);"> 
                <div class="my-3">
                    <h3 class="text-center"><strong>Personal Profile</strong></h3>
                    <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id']; 
                        $firstname = $row['firstname'];
                        $lastname = $row['lastname'];
                        $address = $row['address'];
                        $number = $row['number'];
                        $email = $row['email']; 
                        $gender = $row['gender']; 
                        $country = $row['country']; 
                        $state = $row['state']; 
                        $user_profile = $row['user_pics']; 
                    ?> 
                    <div class="px-2">
                        <div class="row" align="center"> 
                            <div class="col py-2">
                                <img src="<?php echo "$user_profile";?>" width="100px" height="100px"style="border-radius:50%;border:2px solid green;"><br>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Firstname</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$firstname";?></p>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Lastname</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$lastname";?></p>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Email</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$email";?></p>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Home Address</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$address";?></p>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Contact Address</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$number";?></p>
                            </div> 
                        </div>
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Gender</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$gender";?></p>
                            </div> 
                        </div> 
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">Country</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$country";?></p>
                            </div> 
                        </div> 
                        <div class="row" align="left"> 
                            <div class="col">
                                <p class="">State</p>
                            </div> 
                            <div class="col">
                                <p class=""><?php echo"$state";?></p>
                            </div> 
                        </div> 
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-3 side2">
            <div class="l my-2 py-2"align="center" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);">
                <h1 class="text-light">ScoreBoard</h1>
            <div class="title-box"align="center"style="justify-content:space-between;padding: 0 2rem;">
                <p>Home</p>
                <p id="elapsed"></p>
                <p>Away</p>
            </div>
            <div class="title-box"style="justify-content:space-between;padding: 0 2rem;">
                <div class="team">
                    <img  id="homeLogo" >
                    <p id="homeName"></p>
                </div>
                <p id="goals"style="font-size:15px !important;"></p>
                <div class="team">
                    <img id="awayLogo">
                    <p id="awayName"></p>
                     </div>
                 
            </div> 
            <div id="matchTable" class="matches-table">
          
            </div>
        </div>
         <script src="../js/main.js">
           
         </script>
            </div>
    </div>
        <footer class="py-2" style="position:fixed;background:rgb(6, 2, 34); text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;">Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
          </footer>
                        <script type="text/javascript">
                            function loadDoc() {
                            

                            setInterval(function(){

                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("noti_number").innerHTML = this.responseText;
                                }
                            };
                            xhttp.open("GET", "data2.php", true);
                            xhttp.send();

                            },1000);


                            }
                            loadDoc();
                            </script>  
    
        <!-- jquary files-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script src="../icons/js/all.min.js"></script>
    <!-- AOS js file -->
    <script src="../aos-master/dist/aos.js"></script>

    <!-- owl carousel js file --> 
     <script src="../js/owl.carousel.min.js"></script>
     <script src="../js/main.js"></script>

</body> 
</html>
<?php }?>
