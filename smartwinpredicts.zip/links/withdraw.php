<?php
session_start();
include("../connection/connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- bootstrap link -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../icons/css/all.min.css">

    <!-- Owl carousel --> 
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- AOS link --> 
    <link rel="stylesheet" href="../aos-master/dist/aos.css">
 

    <title>Smart-win| Withdraw</title>

    <style>
      
       @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Roboto:ital@1&display=swap'); 
  *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Poppins', sans-serif; 
  }
  
  body{ 
      background:black;
      color:white;
      margin:0;
      padding:0;
      width:100vw;
      box-sizing:border-box;
      overflow-x:hidden;
  }
     .top-header{
         background:rgb(6, 2, 34);
         display:flex; 
         justify-content:space-between;
         align-items:center;
         text-align:center; 
         width:100%;
         z-index:1111;
         box-sizing:border-box;
     }   
     .top-header .top h2{
         color:green;
         padding:.5rem .5rem;
         font-weight:700;
         font-size:25px;
        font-family: 'Poppins', sans-serif;
     }
     .top-header .top span{
         color:yellow;
     }
     
     .top-header .top p{
         color:white;
         padding-left:.5rem;
         position:relative;
         margin-top:-1rem;
     }
     
     .top-header .header{
    position:relative;
    display: flex; 
  } 
  
  header .user_img {
      display:flex; 
      padding:1vh 0; 
      position:relative;
      right:2vw;
  }
  
  header .user_img img{
      margin-right:1vw;
  }
   
   header .user_img p{
       margin-right:1vw;
       padding-top:1vh;
   }
   
   header .nav{
       padding:1vh 1vw;
   }
   
   header .nav a{
       color:white;
       font-weight:600;
   }
   
   header .nav a:hover, header .nav a.active{
       color:green;  
   }
   
   header #menu{
       display:none;
   }
   
    .side1 .q{
       background:#0E402D;
       padding:1vh 1vw;
       margin:2vh 0;
       border-radius:1rem;
    }
    
    .side1 .st{
       background:#0E402D;
       padding:1vh 1vw;
       margin:2vh 0;
       border-radius:1rem; 
    }
    
    .side2 .l{
       background:#0E402D;
       padding:1vh;
       margin:2vh 0;
       border-radius:1rem;
    }
   
      .pay{
        display:flex;
        flex-direction:column;
        padding:3vh 0;
        margin-bottom:3rem;
        justify-content:center; 
        align-items:center;
        text-align:center;
        min-height:80vh;
        width:100vw; 
    }
    
    input[type='email'],
    input[type='num'],
    input[type='text']{
        color:white;
        outline:none;
        border:none;
        border-bottom:2px solid #0E402D ;
        width:80vw; 
        background:transparent;
    }
    
    button{
        background:blueviolet;
        padding:1rem 3rem;
        color:#fff;
        font-weight:bolder;
        border:none;
        outline:none;
        border-radius:3rem;
    } 
     
@media only screen and (max-width:500px){
   
    header #menu{
     display:flex;
     position:relative;
    margin-right:2vw;
 }
 
 header .nav {
     display:none;
 }
 
 header .user_img {
     display:none;
 }
 
 header .offcanvas-body{
     background:black;
     color:#fff !important;
 }
 
 header .offcanvas-body a{
     color:white;
     text-decoration:none;
 }
 
 header .offcanvas-body li a:hover{
     color:#0E402D;
     font-weight:bolder;
 }
 
 header .offcanvas-body li{
     list-style-type:none;
 }
 
 header .offcanvas-body form button{
     background: #0E402D;
     padding:1rem 3rem;
     color:#fff;
     border-radius:3rem;
     border: none;
     outline:none;
 }
 
 header .offcanvas-header{
     background:#0E402D;
 }

header .offcancas-header button{
    color:#fff !important;
}
   .main{
       margin:0 !important; 
       box-sizing:border-box;
       box-shadow:none !important; 
   }
   
   
    .main .plan ul{
        display:flex;
        justify-content:center;
        align-items:center;
        min-width:100vw;
    }
    
    .main .plan ul li{ 
        list-style-type:none;
    }
    
    .main .plan ul li h5{
        font-size:11px;
    }
    
    .main .plan ul li p{
        font-size:10px;
    }
    
    .main .plan{
        margin:0 !important;
        margin-left:-8vw;
        min-width:100vw;
        position:relative;
        left:0 !important;
    }
    .main .note{
        font-size:12px;
        margin-left:3vw;
    }
   
   .top-header{
       display:flex;
       box-shadow:0 0 0 rgb(0,0,0);
   }
   
   .top-header h1{
       margin-top:-2rem;
   }
   
    .top-header img{ 
        width:100px;
        height:100px; 
        margin-bottom:-2rem;
        margin-top:-3rem;
        
    } 
    
    .top-header span{
        margin-top:1rem;
        font-size:25px;
        font-weight:500px;
        height:30px;
    }
    
   
.top-header .header{
    position:relative;
    display: flex; 
  }
  
  .win{
      font-size:10px;
  }
  h3{
      font-size:15px;
  }
  .side1{
      display:none;
  }
  .nav{ 
  }
 .user_img h4{  
     margin-top:-2rem;
  }
    .user_img img{
    float:left; 
     width:80px;
     height:80px;
    position: relative;
    margin-top:-2rem;
    margin-left:1rem;
    }
    
     .depo{
        text-align:center;
    }
    
    .user_img{
        margin-top:-2rem;
    } 
     
   .side2{
       display:none;
   } 
   
   footer{
       font-size:8px;
       position:fixed;
   }
   
   .body{
       max-width:100%;
   }
} 
    </style>
</head>
<body>
    <header class="top-header" id="myHeader">
            <div class="top">
            <h2>Smart<span>Win</span></h2>
                <p>Real Football Predicts</p>
            </div> 
            
        <div id="menu">
            <button class="btn btn-success" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                <i class="fa fa-bars"></i>
            </button>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Menu</h5>
    <button type="button" class="btn-close text-reset" style="margin-right:9vw;color:white !important;" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body" align="left">
      <div>
          <ul>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../pages/home.php">My Profile</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../links/personal_info.php">Personal Info</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../links/account_setting.php">Account Setting</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../play/QS.php">Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="plan.php">Account History</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../links/my_referrals.php">My Referral</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../pages/plan.php">Payment Plan</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/how.php">How To Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/rule.php">Rules</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/contact.php">Contact us</a>
                          </li>
          </ul>
      </div>
    <div>
      <div class="form">
          <form action="#" method="post">
              <button name="logout"><i class="fa fa-power-off" aria-hidden="true"></i>
              </button>
              <?php
        
                if(isset($_POST['logout'])){

                    $user = $_SESSION['email'];
                    $get_user = "select * from users where email='$user'";
                    $run_user = mysqli_query($link, $get_user);
                    $row = mysqli_fetch_array($run_user);

                    $user_id = $row['user_id'];
                    $user_name = $row['firstname'];
                    $Lastname = $row['lastname'];
                    $sex = $row['status']; 
                    $user_profile = $row['user_pics']; 


                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                    echo"<script>window.open('../pages/login.php', '_self')</script>";
                    exit();
                }

            ?>
          </form>
      </div>
    </div> 
  </div>
</div>
                
                </div>
                    <div class="nav"> 
                        <ul class="nav justify-content-center"> 
                          <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="../pages/plan.php">Payment Plan</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/how.php">How To Play</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/home.php">Home</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../pages/contact.php">Contact us</a>
                          </li>
                        </ul> 
                    </div> 
                        <div class="user_img "> 
                        <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $user_name = $row['firstname'];
                        $Lastname = $row['lastname'];
                        $email = $row['email'];
                        $sex = $row['status']; 
                        $user_profile = $row['user_pics'];
                        
                        $get_amount = "select * from users where email='$user'";
                        $run_amount = mysqli_query($link, $get_amount);
                        $row_user = mysqli_fetch_array($run_amount);

                        $id = $row_user[' id'];
                        $amount = $row_user['available_bal' ]; 
                    ?>
                  <div class="d-inline-flex text-light">
                    <div class="right-header-img">
                        <img src="<?php echo "$user_profile";?>" width="40px" height="40px"style="border-radius:50%;border:1px solid green;">
                    </div>  
                        <p><strong><?php echo"$user_name $Lastname"?></strong></p>  
                            <form action="" method="post">
                            <button name="logout" width="10px" class="btn text-center text-light"><i class="fa fa-power-off"></i></button>

                            <?php
                                 
                                if(isset($_POST['logout'])){
                                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                                    echo"<script>window.open('login.php', '_self')</script>";
                                    exit();
                                }

                                ?>
                            </form>  
                    </div>
                </div>
            </div> 
        </header>
    
    <div class="container" align="center">
        <div class="row">
            <div class="pay">
                <form id="paymentForm" method="post">
            <?php
            $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                if(isset($_GET['username'])){
                    global $link;
                    
                    $get_username = $_GET['username'];
                    $get_user = "select * from users where username='$get_username'";
                    $run_user =mysqli_query($link, $get_user);
                    $row_user = mysqli_fetch_array($run_user);
                    
                    $username = $row_user['username'];
                    $firstname = $row_user['firstname'];
                    $lastname = $row_user['lastname'];
                    $email = $row_user['email'];
                    $withdraw = $row_user['withdraw'];
                     
                }
            ?>
            
            <div class="form-group">
    <h1>Withdrawal Slip</h1>
    
  <div class="row d-flex my-2">
  <div class="col"> 
    <?php echo "<input type='email' id='email-address' value=  '$email' name='email'  required  />";?>
    <label for="email">Email Address</label>
  </div> 
  
  <div class="col">
    <input type="text" id="first-name" name="first_name" value="<?php echo $firstname;?>" /><br>
    <label for="first-name">First Name</label>
  </div>

  <div class="col">
    <input type="text" id="last-name" name="last_name" value="<?php echo $lastname;?>" /><br>
    <label for="last-name">Last Name</label>
  </div>
  
  </div>
  
  <div class="row d-flex my-2">
      <div class="col">
        <input type="text" id="first-name" name="acct_name" />
        <label for="acct-name">Account Name</label>
      </div> 
  </div>
  
  <div class="row d-flex my-2">
      <div class="col">
        <input type="num" id="accountNum" name="accountNum" required />
        <label for="accountNum">Acount number</label>
      </div> 
      
      <div class="col">
        <input type="text" id="bankcode" name="bankcode" required /><br>
        <label for="bankcode">Bank Name</label>
      </div> 
      
      <div class="col">
        <input type="num" id="amount" name="amount" value="<?php echo $withdraw;?>" required /><br>
        <label for="amount">Amount</label>
      </div> 
   </div>
  <div class="form-submit">

    <button type="submit" name="submit"> Withdraw </button>

  </div>
           <?php
        /* Attempt MySQL server connection. Assuming you are running MySQL
        server with default setting (user 'root' with no password) */
        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
        
        // Check connection
        if($link === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        }
        
        
        // Escape user inputs for security
        if(isset($_POST['submit'])){
        $email = mysqli_real_escape_string($link, $_REQUEST['email']);
        $first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
        $last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
        $acct_name = mysqli_real_escape_string($link, $_REQUEST['acct_name']);
        $accountNum = mysqli_real_escape_string($link, $_REQUEST['accountNum']);
        $bankcode = mysqli_real_escape_string($link, $_REQUEST['bankcode']);
        $amount = mysqli_real_escape_string($link, $_REQUEST['amount']); 
 
                        
                        $get_users = "select * from withdraw_request where email='$email'";
                        $run_users = mysqli_query($link, $get_users);
                        $rows = mysqli_fetch_array($run_users);

                        $id = $rows['id'];  
                        $result2 = $rows['amount']; 
            
        
                $check_amount = "select * from users where firstname ='$first_name'";
                $run_amount = mysqli_query($link, $check_amount);
                $row_amount = mysqli_fetch_array($run_amount);
                    
                    $username = $row_user['username'];
                    $withdraw2 = $row_user['withdraw']; 
                    
                    ?> 
                <?php
                if($amount > $withdraw2){

                    echo"<script>alert('you dont have up to that amount $username!')</script>";
                    echo"<script>window.open('withdraw.php'?username = $username, '_self')</script>";
                    exit();
                } 
 
                 if($amount == ''){
                    echo"<script>alert('input amount')</script>";
                 } 
                 
                 if($acct_name== ''){
                    echo"<script>alert('input account name')</script>";
                 } 
                 if($accountNum == ''){
                    echo"<script>alert('input account number')</script>";
                 } 
                  
        
            $withdraw_amt = $amount + $result2;
        // Attempt insert query execution
                $check_email = "select * from withdraw_request where email='$email'";
                $run_email = mysqli_query($link, $check_email);

                $check = mysqli_num_rows($run_email);

                if($check==1){
                        $update = mysqli_query($link, "UPDATE withdraw_request SET amount='$amount' WHERE email='$email'"); 
                        $update = mysqli_query($link, "UPDATE withdraw_request SET total_withdraw='$withdraw_amt' WHERE email='$email'"); 
                        echo"<script>window.open('../pages/home.php?username=$username', '_self')</script>";  
                } 
                if($check!= 1){
                     $sql = "INSERT INTO withdraw_request (firstname, lastname, acct_name, accountNum, bankcode, amount, email, total_withdraw, date)
                    VALUES ('$firstname', '$lastname', '$acct_name', '$accountNum', '$bankcode', '$amount', '$email', '$withdraw_amt', NOW() )"; 
                }
       
        if(mysqli_query($link, $sql)){ 
            echo"<script>alert('Congratulations $firstname $lastname!, your information submitted successfully')</script>";
            echo"<script>window.open('../pages/home.php?username=$username', '_self')</script>";
        } else{
            echo"<script>alert('Sorry $firstname $lastname!, your information is not correct, try again')</script>";
            echo"<script>window.open('withdraw.php', '_self')</script>";
        } 
 
     
 
// Close connection
mysqli_close($link);
}
?>
            </div> 
        </form> 
            </div>
        </div> 
    </div>
     <footer class="py-2" style="position:fixed; text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;background:rgb(6, 2, 34);">
                         Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
                        </footer>
     <!-- jquary files-->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script src="../icons/js/all.min.js"></script>
    <!-- AOS js file -->
    <script src="../aos-master/dist/aos.js"></script>

    <!-- owl carousel js file --> 
     <script src="../js/owl.carousel.min.js"></script> 

</body> 
</html>