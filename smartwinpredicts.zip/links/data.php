<?php
$servername = "localhost";
$username = "u696338378_smart_win";
$password = "Sammywendy@234#";
$dbname = "u696338378_smartwindb";
 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

session_start();
require ('../connection/connection.php');

$user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $user_name = $row['username'];
                        $Lastname = $row['lastname'];
                        $sex = $row['status']; 
                        $user_profile = $row['user_pics'];
                        
                         $get_users = "select * from users where referral_id='$user_id'";
                        $run_users = mysqli_query($link, $get_users);
                        $rows = mysqli_fetch_array($run_users);
                        
                       $get_ref = "SELECT SUM(total_withdraw) AS sum FROM `withdraw_request` where status='paid'";
                       $pick = mysqli_query( $link, $get_ref);
                       
     while($rop = mysqli_fetch_assoc($pick)){
         $ref_amount= $rop['sum'];
         
         $ref = $ref_amount * 0.03;
     }
                   
                        
                        
                        
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM users where   referral_id = '$user_id'";
$result = $link->query($sql);

$sql2 = "SELECT * FROM booking where   player_name = '$user_name'";
$result2 = $link->query($sql2);
echo"<strong>NGN &nbsp</strong>";
echo  $result->num_rows * '100'+ $ref;
/*
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Notification: " . $row["status"];
    }
} else {
    echo "<div class='d-none'>0 results</div>";
}
*/
$conn->close();
?>