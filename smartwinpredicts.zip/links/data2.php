<?php
$servername = "localhost";
$username = "u696338378_smart_win";
$password = "Sammywendy@234#";
$dbname = "u696338378_smartwindb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

session_start();
require ('../connection/connection.php');

                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];   
                        $result2 = $row['deposit']; 
                        
                         $users = $_SESSION['email'];
                        $get_users = "select * from withdraw_request where email='$users'";
                        $run_users = mysqli_query($link, $get_users);
                        $rows = mysqli_fetch_array($run_users);

                        $id = $rows['id'];  
                        $results = $rows['total_withdraw']; 
                        
                         
                         $get_usere = "select * from users where referral_id='$user_id'";
                        $run_usere= mysqli_query($link, $get_usere);
                        $rowe = mysqli_fetch_array($run_usere);
                        
                        
                        $referral_id = $rowe['referral_id'];
                        $user_namea = $rowe['username']; 
                        $user_mail = $rowe['email']; 
                        
                        $get_ref = "select * from withdraw_request where email='$user_mail'";
                        $run_ref = mysqli_query($link, $get_ref);
                        $row_ref = mysqli_fetch_array($run_ref);
                        
                        $ref_name = $row_ref['firstname'];
                        $ref_amount = $row_ref['total_withdraw'];
                        $ref_name = $row_ref['username'];
                        
                        $ref = $ref_amount * 0.03;
                        
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM users where   referral_id = '$user_id'";
$result = $link->query($sql);

$sql0 = "SELECT * FROM booking where   player_name = '$user_name' and QS='Yes'";
$result0 = $link->query($sql0);
  

$sql3 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash1'";
$result3 = $link->query($sql3);

$sql4 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss1'";
$result4 = $link->query($sql4);

$sql5 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward1'";
$result5 = $link->query($sql5);


$sql6 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash2'";
$result6 = $link->query($sql6);

$sql7 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss2'";
$result7 = $link->query($sql7);

$sql8 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward2'";
$result8 = $link->query($sql8);


$sql9 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash3'";
$result9 = $link->query($sql9);

$sql10 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss3'";
$result10 = $link->query($sql10);

$sql11 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward3'";
$result11 = $link->query($sql11);


$sql12 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash4'";
$result12 = $link->query($sql12);

$sql13 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss4'";
$result13 = $link->query($sql13);

$sql14 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward4'";
$result14 = $link->query($sql14);


$sql15 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash5'";
$result15 = $link->query($sql15);

$sql16 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss5'";
$result16 = $link->query($sql16);

$sql17 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward5'";
$result17 = $link->query($sql17);


$sql18 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash6'";
$result18 = $link->query($sql18);

$sql19 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss6'";
$result19 = $link->query($sql19);

$sql20 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward6'";
$result20 = $link->query($sql20);


$sql21 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash7'";
$result21 = $link->query($sql21);

$sql22 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss7'";
$result22 = $link->query($sql22);

$sql23 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward7'";
$result23 = $link->query($sql23);


$sql24 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash8'";
$result24 = $link->query($sql24);

$sql25 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss8'";
$result25 = $link->query($sql25);

$sql26 = "SELECT * FROM booking where   player_name = '$user_name' and reward='reward8'";
$result26 = $link->query($sql26);


$sql27 = "SELECT * FROM booking where   player_name = '$user_name' and status='cash9'";
$result27 = $link->query($sql27);

$sql28 = "SELECT * FROM booking where   player_name = '$user_name' and status='loss9'";
$result28 = $link->query($sql28); 

  $bal =  $result->num_rows * '100' - $result0->num_rows * '500' + $ref + $result2 - $results + $result3->num_rows * '1000' + $result4->num_rows * '500'+ $result5->num_rows * '500'  + $result6->num_rows * '5000' + $result7->num_rows * '700' + $result8->num_rows * '1500' + $result9->num_rows * '12000' + $result10->num_rows * '1000' + $result11->num_rows * '2500' + $result12->num_rows * '40000' + $result13->num_rows * '1500' + $result14->num_rows * '4500' + $result15->num_rows * '80000' + $result16->num_rows * '20000' + $result17->num_rows * '9500'+ $result18->num_rows * '200000' + $result19->num_rows * '25000' + $result20->num_rows * '14500'
    + $result21->num_rows * '500000' + $result22->num_rows * '50000' + $result23->num_rows * '29500'
    + $result24->num_rows * '1000000' + $result25->num_rows * '100000' + $result26->num_rows * '79500'
    + $result27->num_rows * '2500000' + $result28->num_rows * '200000' 
     ;
      
      echo " <strong>NGN<strong> $bal";
   
   
    $Update = mysqli_query($link, "UPDATE users SET available_bal='$bal' WHERE email='$user'");
/*
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Notification: " . $row["status"];
    }
} else {
    echo "<div class='d-none'>0 results</div>";
}
*/
$conn->close();
?>