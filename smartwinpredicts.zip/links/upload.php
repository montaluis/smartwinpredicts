<?php

session_start();

include("../connection/connection.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./icons/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <title>change profile picture</title>
</head>
<style>
    .card{
        width:400px;
        height:440px;
        box-shadow: 2px 5px 12px rgba(0,0,0,.5);
        padding:5px;
        }
    .card img{
        padding:0;
        height:280px;
    }
    .card h1{
        text-transform:capitalize;
        font-weight:800;
        font-family:calibri;
        text-align:center;

    }
    input[type="file"]{
        display:none;
    }
    #update_profile{
        cursor:pointer;
        padding:10px;
    }
    a{
        color:white;
        font-weight:800;
    }
</style>

<body>

    <?php
    
    $user = $_SESSION['email'];
    $get_user ="select * from users where email='$user'";
    $run_user = mysqli_query($link, $get_user);
    $row = mysqli_fetch_array($run_user);

    $username = $row['username'];
    $user_profile = $row['user_pics'];

    echo"
        <div align='center'>
            <div class='card' align='center'>
                <img src='$user_profile'>
                <h1> $username</h1>
                <form method='post' enctype='multipart/form-data'>

                <label id='update_profile'><i class='fas fa-circle' aria-hidden='true'></i>Select Profile
                <input type='file' name='u_image' size='60'>
                </label>
                <button id='button_profile' name='update'>&nbsp<i class='fa fa-heart' aria-hidden='true'></i>&nbsp&nbspupdate profile</button>
                <button class='btn btn-info'><a href='account_setting.php'>Done</a></button>
                </form>
            </div>
        </div>
    ";

    if(isset($_POST['update'])){
        $u_image = $_FILES['u_image']['name'];
        $image_tmp = $_FILES['u_image']['tmp_name'];
        $random_number = rand(1,1000);

        if($u_image ==''){
            echo"<script>alert('Please select profile')</script>";
            echo"<script>window.open('upload.php', '_self')</script>";
            exit();
        }else{

            move_uploaded_file($image_tmp, "../img/$u_image.$random_number");

            $update = "update users set user_pics='../img/$u_image.$random_number'where email='$user'";

            $run = mysqli_query($link, $update);

            if($run){
                echo"<script>alert('Your profile Updated successfully')</script>";
                echo"<script>window.open('upload.php', '_self')</script>";
            }
        }
    }
    
    ?>

<footer class="bg-dark py-2" style="font-size:14px;position:fixed; text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;">
                         Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
                        </footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src="./icons/js/all.min.js"></script>
</body>
</html>