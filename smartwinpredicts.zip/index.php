<!DOCTYPE html> 
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Smartwin Predicts</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Roboto:ital@1&display=swap'); 
  *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Poppins', sans-serif;
      
  }
  
 body{ 
     display:flex;
  color: white;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background-color: rgb(1, 0, 7);
  padding: 0 10px; 
}

  .web-name h2{
    color:green;
    font-size:30px;  
  }
  
  .web-name .p1{
      font-size:20px;
    position: relative;
      top:-0.7rem; 
  }
  span{
      color:yellow;
      font-size:30px;
  }
  .logo{  
    position: relative;
    top:-2.5rem;
} 

@media screen and (max-width: 320px){
    
}
</style>
</head>
<body>
    <div class="d-flex web-name" align="center">
      <h2>Smart<span>Win</span></h2>
      <p class="p1">Real Football Predicts</p>
        <div class="d-flex logo" align="center"> 
            <img src="./img/loader.gif" alt="Loading" style="width:100px;height:100px;"> 
        </div>
    </div> 

  <script src="script.js"></script>
</body>
</html>
</body>
</html>