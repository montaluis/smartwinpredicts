(function(){

    var preload = document.getElementById("logo");
    var loading = 0;
    var id = setInterval(frame, 80);

    function frame(){
        if(loading == 60) {
            clearInterval(id);
            window.open("welcome.php", "_self");
        }else{
            loading = loading + 1;
            if(loading == 90){
                logo.style.animation = "fadeout";
            }
        }
    }

})();