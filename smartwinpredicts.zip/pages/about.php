 <?php
    session_start();
    include('../connection/connection.php');

    
if(!isset($_SESSION['email'])){
    header("location: login.php");
}
else {

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- bootstrap link -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../icons/css/all.min.css">

    <!-- Owl carousel --> 
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- AOS link --> 
    <link rel="stylesheet" href="../aos-master/dist/aos.css">

    <!-- main css link -->
    <link rel="stylesheet" href="../css/login.css">

    <title>Smart-win| About</title>

    <style>
       .main {
    overflow-y:scroll;
    overflow-x:hidden;
    background-color:transparent;
    position: relative;
    display: block;
    height:450px;
       } 
       .newsgrid img{
           width: calc(120%);
           height: 70px;
           margin-top:1rem;
           margin-right:1rem;
       }
    .newsgrid{
        border: 1px solid #ddd;
        margin:.5rem;
        padding:.7rem;
    }
    
    @media only screen and (max-width:500px){
   
   .top-header{
       display:flex;
       box-shadow:0 0 0 rgb(0,0,0);
   }
   
   .top-header h1{
       margin-top:-2rem;
   }
   
    .top-header img{ 
        width:100px;
        height:100px; 
        margin-bottom:-2rem;
        margin-top:-3rem;
        
    } 
    
    .top-header span{
        margin-top:1rem;
        font-size:25px;
        font-weight:500px;
        height:30px;
    }
    
   
.top-header .header{
    position:relative;
    display: flex; 
  }
  
  .win{
      font-size:10px;
  }
  h3{
      font-size:15px;
  }
  .side1{
      display:none;
  }
  .nav{ 
  }
 .user_img h4{  
     margin-top:-2rem;
  }
    .user_img img{
    float:left; 
     width:80px;
     height:80px;
    position: relative;
    margin-top:-2rem;
    margin-left:1rem;
    }
    
     .depo{
        text-align:center;
    }
    
    .user_img{
        margin-top:-2rem;
    }
    
   .main{
       display: flex;
       flex:flex-wrap;
       position:relative;
   } 
   .side2{
       display:none;
   }
} 
    </style>
</head>
<body class="bg-dark">

<header class="top-header"style="box-shadow: 3px 0px 10px rgba(225,225,225,0.567);">
            <div class="row">
                <div class="col-md-12"align="center">
                    <div class="row">
                        <div class="col-md-3 col-sm-4 col-xs-3" >
                            <div class="web_image"align="center" style="margin-top:5rem;">
                                <img src="../img/images.png" alt="img1" width="150px" height="130px">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-7 col-xs-6 py-2">
                            <h1 class="web_name" style="color:#fff;font-size:50px;font-weight:800;margin-top:1rem !important;"><span>SMART</span><strong style='color:yellow;font-size:30px;font-style:italic;margin-top:1rem;'>WIN</strong></h1>
                            <h3 style="letter-spacing:1rem; color:yellow;">Real Footbal Predicts</h3>
                            <div class="row nav "align="center" style="background-color:green; margin-top:1rem;padding-bottom:1rem;">
                                <div class="col"><a href="../pages/plan.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'> Payment Plan</a></div>
                                <div class="col"><a href="../pages/how.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>How To Play</a></div>
                                <div class="col"><a href="../pages/rule.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>Rules</a></div>
                                <div class="col"><a href="../pages/contact.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>Contact us</a></div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-3"> 
                        <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $user_name = $row['firstname'];
                        $Lastname = $row['lastname'];
                        $sex = $row['status']; 
                        $user_profile = $row['user_pics']; 
                    ?>
                  <div class="user_img d-inline-flex text-light" style="margin-top:3rem;">
                    <div class="right-header-img">
                        <img src="<?php echo "$user_profile";?>" width="100px" height="100px"style="border-radius:50%;border:2px solid green;">
                    </div>
                     <div class="mx-2 my-4">   
                        <h4><strong><?php echo"$user_name $Lastname"?></strong></h4>
                        <div class="row d-flex d-inline-flex">
                            <div class="col-md-5 col-sm-9 d-flex">
                            <p class="text-center text-light" style="margin-right:.5rem;"><a href="../play/payment.php"class="text-center text-light">deposit:# </a></p>
                            <h4><strong><?php echo"#"?></strong></h4><p id="noti_number"></p>
                            </div> 
                            <div class="col-md-3">
                            <form action="" method="post">
                            <button name="logout" width="10px" class="btn text-center text-light"><i class="fas fa-door-open"></i></button>

                            <?php
        
                                if(isset($_POST['logout'])){
                                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                                    echo"<script>window.open('../pages/login.php', '_self')</script>";
                                    exit();
                                }

                                ?>
                            </form>
                            </div>
                        </div>
                            <div class="chat-flow"> 
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </header>
        <div class="row d-flex main">
            <div class="col-md-3 col-sm-4 col-xs-12">
                <div class="statistics style='opacity:.7;">
                        <div class="header-statistics">
                        <div class="theme">
                                <div class=' mx-2' style='background-color:green;color:white;border-radius:2rem; margin-bottom: 1rem; margin-top: 1rem;padding:.5rem 0;' align='center'>
                                <h3 class='text-center'><strong>Quick Links</strong></h3>
                                <ul class='text-left'style='list-style-type:none;padding-right:1.5rem;'>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../pages/home.php" class="active" style="color:white !important;"><i class="fa fa-user-circle" aria-hidden="true"></i> My Profile</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/personal_info.php" style="color:white !important;"><i class="fa fa-address-book" aria-hidden="true"></i> Personal Info</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/account_setting.php" style="color:white !important;"><i class="fa fa-cogs" aria-hidden="true"></i> Account Setting</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../play/QS.php" style="color:white !important;"><i class="fa fa-futbol" aria-hidden="true"></i> Play</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="#" style="color:white !important;"><i class="fa fa-database" aria-hidden="true"></i> Account History</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/my_referrals.php" style="color:white !important;"><i class="fa fa-users" aria-hidden="true"></i> My Referrals</a></h5></li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        <?php
                        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                        $total_messages = "select * from users";
                        $run_messages = mysqli_query($link, $total_messages);
                        $total = mysqli_num_rows($run_messages);

                        $online_members = "select * from users where status='Online'";
                        $run_online = mysqli_query($link, $online_members);
                        $sum = mysqli_num_rows($run_online);?>
                         <?php 
                       $selects = "SELECT SUM(total_withdraw) AS sum FROM `withdraw_request` where status='paid'";
                       $pick = mysqli_query( $link, $selects);
                       
     while($row = mysqli_fetch_assoc($pick)){
         $paid= $row['sum'];
     }
                  
                        
                  
                      ?>
                        <?php
                           
                           $date =date("Y-m-d");
                           echo"<div class='text-center text-light'>$date</div>";
                           $today_members = "select * from users where date='$date'";
                        $run_today = mysqli_query($link, $today_members);
                        $today = mysqli_num_rows($run_today);

                        ?>
                        <?php
                        echo "<div class=' mx-2' style='box-shadow:
                        3px 4px 10px rgba(225,225,225,0.567);background-color:green;border-radius:2rem;padding:.5rem 0;' align='center'>
                        <h3 class='text-center text-light'><strong>STATISTICS</strong></h3>
                            <ul class='text-center d-flex'style='list-style-type:none;padding-right:1.5rem; color: yellow;'>
                                <li ><h4>  $total </h4><small>Total Members</small></li>
                                <li ><h4>$today</h4><small>Joined Today</small></li>
                                <li ><h4> $sum </h4><small>Online Members</small></li>
                                <li ><h4>$paid</h4><small>Total Payments</small></li>
                            </ul>
                        </div>";
                        ?> 
            </div> 
         </div>
         <div class="col-md-6 bg-light" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);"> 
                <div class="my-3">
                    <h3 class="text-center"><strong>About Us</strong></h3>
                    <h3 class="text-center"style="letter-spacing:1rem;">Smart Win</h3>
                    <p class="text-center"style="letter-spacing:1rem;">Real Football Predicts</p>
                    <P> &nbsp &nbsp &nbspLorem ipsum dolor sit amet consectetur, adipisicing elit. Quod ratione autem 
                        consequuntur sapiente doloribus quibusdam adipisci quis, ad accusamus suscipit 
                        quas iure repellat labore sit error quae nobis exercitationem odit soluta fuga 
                        libero? Placeat accusamus aspernatur ea quia ab molestiae, at quaerat quasi amet, 
                        nemo perferendis voluptates! Totam eligendi iure molestiae illum consequuntur dolore 
                        iusto odio ratione, quaerat repudiandae quibusdam facilis eos rem assumenda officia 
                        velit, voluptates perferendis quas! Veritatis, officiis nulla dicta error amet sint 
                        dolor voluptatibus repellat, accusamus incidunt minima sapiente accusantium, recusandae 
                        nesciunt hic odit aliquam eaque ea.
                         Sunt tenetur numquam unde suscipit odit deleniti pariatur quos.</P>
                    <div class="row my-3">
                                <div class="col-md-2 col-sm-2 text-center my-3">
                                    <h3>Stage</h3><br>
                                    <p>1</p>
                                    <p>2</p>
                                    <p>3</p>
                                    <p>4</p>
                                    <p>5</p>
                                    <p>6</p>
                                    <p>7</p>
                                    <p>8</p>
                                    <p>9</p>
                                </div>
                                <div class="col-md-2 col-sm-2 text-center my-3">
                                <h3>Odds </h3><br>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>3.5</p>
                                    <p>3.5</p>
                                    <p>3</p>
                                </div>
                                <div class="col-md-3 col-sm-3 text-center">
                                <h3>Reward <br>(Win)</h3>
                                    <p>#1,000</p>
                                    <p>#5,000</p>
                                    <p>#12,000</p>
                                    <p>#40,000</p>
                                    <p>#80,000</p>
                                    <p>#200,000</p>
                                    <p>#500,000</p>
                                    <p>#1,000,000</p>
                                    <p>#2,500,000</p>
                                </div>
                                <div class="col-md-2 col-sm-2 text-center">
                                <h3>Reward (Loss)</h3>
                                    <p>#500</p>
                                    <p>#700</p>
                                    <p>#1,000</p>
                                    <p>#1,500</p>
                                    <p>#20,000</p>
                                    <p>#25,000</p>
                                    <p>#50,000</p>
                                    <p>#100,000</p>
                                    <p>#200,000</p>
                                </div> 
                                <div class="col-md-2 col-sm-2 text-center">
                                <h3>Rewards Con't</h3>
                                    <p>#500</p>
                                    <p>#1,000</p>
                                    <p>#1,000</p>
                                    <p>#2,000</p>
                                    <p>#5,000</p>
                                    <p>#5,000</p>
                                    <p>#10,000</p>
                                    <p>#50,000</p>
                                    <p>-</p>
                                </div> 
                     </div><hr>
                     <ul>
                        <li class="d-flex"><h5>Reward Win:</h5><p class="my-1 px-1">The amount you recieve when you win and want to stop at a stage.</p></li>
                        <li class="d-flex"><h5>Reword Loss:</h5><p class="my-1 px-1">The amount you recieve when you loss at a stage.</p></li>
                        <li class="d-flex"><h5>Reword Con't:</h5><p class="my-1 px-1">The amount you recieve when you and still proceed to next stage.</p></li>
                     </ul><hr> 
                    <p>&nbsp &nbsp &nbsp Purchase a Smart Win card for #500, fill and submit the card. Immediately #500 would be deducted
                    from your account. Predict any 4 odds of your choice and play it on any sport betting website like Bet9ja or
                    1x bet. Fill in the bet code in the smart win card also at least 60 mins before the game begins. Once your prediction
                    is correct, you will and a success notification which makes you qualified to play and win the 2.5million for free.</p>
                    <p>&nbsp &nbsp &nbsp You have 9 stages to complete to win the #2.5million at your own choice.</p>
                    <ul>
                        <li><p>At each stage you give correct prediction, you have a prize to win.</p></li>
                        <li><p>You are free to walk away with your prize or proceed to the next stage.</p></li>
                        <li><p>You have maximum of 12 games of your choice to predict at each stages</p></li>
                        <li><p>State 1-6 you predict outcome of any game(s) of your choice with minimum total odd of 4.</p></li>
                        <li><p>State 7-8 you predict outcome of any game(s) of your choice with minimum total odd of 3.5. and at stage 9 you predict total odd of 3.</p></li>
                        <li><p>you only have 2weeks to complete the 9 stages.</p></li>
                        <li><p>you must submit your game at least 3hours before the starting of the first game.</p></li>
                    </ul>
                    <p><strong>For Enquiry or Complain call 08158251913 or visit the contact us link to send mail to us</strong></p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3 side2">
            <div class="my-2 py-2"align="center" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);border-radius:0 2rem;background-color:green;">
                    <?php
                        $url = 'https://newsapi.org/v2/top-headlines?country=ng&apiKey=2ead2876b4c540559124e23512d5ffd3';
                        $response = file_get_contents($url);
                        $NewsData = json_decode($response);
                   ?>
                    <header>
                        <h2 class="text-light">Latest News</h2>
                    </header> 
                    <div class="body text-light">
                                <?php
                                    foreach($NewsData->articles as $News){

                                    
                                ?>
                                <div class="row newsgrid">
                                        <div class="col-md-3">
                                            <img src="<?php echo $News->urlToImage ?>" alt="News img">
                                        </div>
                                        <div class="col-md-9 text-left">
                                            <p class="mx-1"><strong>Title: <?php echo $News->title ?></strong></p>
                                        </div>
                                        <div class="text-left mx-1">
                                            <p><strong>Description:</strong> <?php echo $News->description ?></p>
                                            <p><strong>Content:</strong> <?php echo $News->content ?></p>
                                            <p><strong>Aurthor:</strong> <?php echo $News->author ?></p>
                                            <p><strong>Published:</strong> <?php echo $News->publishedAt ?></p>
                                            <p><strong>Read More:</strong> <?php echo "<a href='$News->url'>$News->url </a>";?></p>
                                        </div>
                                </div>
                                <?php }?>
                    </div>
                </div> 
            </div>

            
                      

                        <footer class="bg-dark py-2" style="font-size:14px;position:fixed; text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;">
                         Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
                        </footer>   
    

                        <script type="text/javascript">
                            function loadDoc() {
                            

                            setInterval(function(){

                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("noti_number").innerHTML = this.responseText;
                                }
                            };
                            xhttp.open("GET", "../links/data2.php", true);
                            xhttp.send();

                            },1000);


                            }
                            loadDoc();
                            </script>
        <!-- jquary files-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script src="../icons/js/all.min.js"></script>
    <!-- AOS js file -->
    <script src="../aos-master/dist/aos.js"></script>

    <!-- owl carousel js file --> 
     <script src="../js/owl.carousel.min.js"></script> 

</body> 
</html>
<?php }?>
