        <?php
        /* Attempt MySQL server connection. Assuming you are running MySQL
        server with default setting (user 'root' with no password) */
        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
        
        // Check connection
        if($link === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        }
        
        // Escape user inputs for security
        if(isset($_POST['next1'])){
        $firstname = mysqli_real_escape_string($link, $_REQUEST['firstname']);
        $lastname = mysqli_real_escape_string($link, $_REQUEST['lastname']);
        $gender = mysqli_real_escape_string($link, $_REQUEST['gender']);
        $email = mysqli_real_escape_string($link, $_REQUEST['email']);
        $address = mysqli_real_escape_string($link, $_REQUEST['address']);
        $number = mysqli_real_escape_string($link, $_REQUEST['number']);
        $country = mysqli_real_escape_string($link, $_REQUEST['country']);
        $state = mysqli_real_escape_string($link, $_REQUEST['state']); 
        $username = mysqli_real_escape_string($link, $_REQUEST['username']);
        $password = mysqli_real_escape_string($link, $_REQUEST['password']);
        $confirm_password = mysqli_real_escape_string($link, $_REQUEST['confirm_password']);  
        $referral_id = mysqli_real_escape_string($link, $_REQUEST['referral_id']);
        $rand = rand(1,2);
 
        
                $check_email = "select * from users where email='$email'";
                $run_email = mysqli_query($link, $check_email);

                $check = mysqli_num_rows($run_email);

                if($check==1){

                    echo"<script>alert('Email already exits $firstname $lastname!')</script>";
                    echo"<script>window.open('register.php', '_self')</script>";
                    exit();
                }
                
                $check_ref = "select * from users where user_id='$referral_id'";
                $run_ref = mysqli_query($link, $check_ref);

                $check = mysqli_num_rows($run_email);

                if($check==2){

                    echo"<script>alert('available $firstname $lastname!')</script>"; 
                }
                
                if($rand == 1)
                 $profile_pics = "../img/images4.png";
                 
                 else if($rand == 2) $profile_pics = "../img/images4.png";

                 if($username == ''){
                    echo"<script>alert('username could not be verified')</script>";
                 }
                 if(strlen($password)<8){
                     echo"<script>alert('password should not be less than 8 characters!')</script>";
                     exit();
                 }
                 
                 if($password == $confirm_password){
                                 echo"<script>alert('$username password configured')</script>";
                             }
                             else{
                                 echo"<script>alert('passwords do not match, check to confirm')</script>";
                                 exit();
                             }

        // Attempt insert query execution
        $sql = "INSERT INTO users (firstname, lastname, gender, email, address, number, country, state, user_pics, status, forgotten_answer,
        username, password, confirm_password, acct_name, bank_name, acct_num, referral_id, date)
        VALUES ('$firstname', '$lastname', '$gender', '$email', '$address', '$number', '$country', '$state', 
         '$profile_pics', 'offline', '','$username', '$password', '$confirm_password', '$acct_name', '$bank_name', '$acct_num', '$referral_id', NOW())";
        if(mysqli_query($link, $sql)){
            echo"<script>alert('Congratulations $firstname $lastname!, your information submitted successfully')</script>";
            echo"<script>window.open('login.php', '_self')</script>";
        } else{
            echo"<script>alert('Sorry $firstname $lastname!, your information is not correct, try again')</script>";
            echo"<script>window.open('register.php', '_self')</script>";
        } 
 
     
 
// Close connection
mysqli_close($link);
}
?>