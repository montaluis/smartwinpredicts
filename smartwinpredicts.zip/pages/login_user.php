<?php
 

include("../connection/connection.php");

    if(isset($_POST['submit'])){
       
        $Pass = htmlentities(mysqli_real_escape_string($link, $_POST['password']));
        $Email = htmlentities(mysqli_real_escape_string($link, $_POST['email']));

        $select_user = "select * from users where email='$Email' AND password='$Pass'";

        $query = mysqli_query($link, $select_user);
        $check_user = mysqli_num_rows($query);

        if($check_user == 1){
            $_SESSION['email']=$Email;

            $update_msg = mysqli_query($link, "UPDATE users SET status='Online' WHERE email='$Email' ");

            $user = $_SESSION['email'];
            $get_user = "select * from users where email='$user'";
            $run_user = mysqli_query($link, $get_user);
            $row = mysqli_fetch_array($run_user);

            $username = $row['username'];

            echo "<script>window.open('home.php?username=$username', '_self')</script>";
        }
        else{
            echo"
            
            <div class='alert alert-danger'>
                <strong>check your username and password.</strong>
            </div>

            ";
        }
    }
?>