<?php

session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- bootstrap link -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- main css link -->
    <link rel="stylesheet" href="../css/login.css">

    <title>Smart-win| Login</title>
    <style>
     @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Roboto:ital@1&display=swap'); 
  *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Poppins', sans-serif;
      
  }
  
  body{ 
      background:black;
      color:white;
      margin:0;
      padding:0;
      box-sizing:border-box;
  }
     .top-header{
         background:rgb(6, 2, 34);
         display:flex; 
         justify-content:center;
         text-align:center;
         width:100%;
         z-index:111111;
     }  
     .top-header .top{  
         display:block;
     }
     .top-header .top h2{
         color:green;
         padding:.5rem .5rem;
         font-weight:700;
         font-size:25px;
        font-family: 'Poppins', sans-serif;
     }
     .top-header .top span{
         color:yellow;
     }
     
     .top-header .top p{
         color:white;
         padding-left:.5rem;
         position:relative;
         margin-top:-1rem;
     }
     
     .top-header .header{
    position:relative;
    display: flex; 
  } 
   .main btn1{ 
         height:6vh;
         width:25vw;
     }
     
     .main a{
         padding-right:2vw;
         padding-top:1vh;
         padding-bottom:1vh;
         margin-top:3vh;
         margin-right:2vw; 
         border-radius:1.5rem;
         background:transparent;
         border:1px solid green;
         font-weight:600;
         display:flex;
         justify-content:center;
         align-items:center;
         color:white;
         text-align:center;
     }
     
     .main a:hover{ 
         text-decoration:none;
         background:rgba(0, 128, 0, 0.24);
     }
     
     .main h1{
         font-size:20px;
         font-weight:bold;
     }
     
     .main p{
         font-size:14px;
     }
     
  .form{
         width:100%;
         padding:10px;
     }
     
     .side2{
         background:black;
     }
      
    
    button{
        background:blueviolet;
        padding:1rem 3rem;
        color:#fff;
        font-weight:bolder;
        border:none;
        outline:none;
        border-radius:3rem;
    } 
     
     input[type='email'],
    input[type='password']{
        color:white;
        outline:none;
        background:transparent;
        border:none;
        border-bottom:2px solid #0E402D ;
        margin-top:3vh;
        width:80%;
    }
      
     .carousel{
         display:none;
         width:100%; 
         position:absolute;
         top:0;
         left:0;
         filter: blur(8px);
         -webkit-filter: blur(8px);
         z-index:-111;
     }
     
     .cover{
         position:fixed;
         min-height:100%;
         width:100vw;
         background:black;
         opacity:.7;
         top:0;
         left:0; 
         z-index:-1;
     }
    
@media only screen and (max-width:500px){
      
   .carousel{
         display:flex;
       
   }
    .top-header img{ 
        width:100px;
        height:80px; 
        margin-bottom:-2rem;
        
    } 
    
    .top-header span{
        margin-top:1rem;
        font-size:25px;
        font-weight:500px;
        height:30px;
    }
    
   .main{
       margin-bottom:13vh;
   }
   
   footer{
       font-size:8px;
   }

  h3{
      font-size:15px;
  }
  .side1{
      display:none;
  }
  .nav{
      display:none;
  }
 .right-header-contentChat .rightside-right-chat span{  
    padding: 10px; 
    color: #fff;
  }
    .rightside-left-chat{
    float:left;
    width: 80%;  
    position: relative;
    }
    .rightside-right-chat{
    float:right;
    width: 80%;
    margin-top:10px;
    position: relative; 
    margin-right: 0;
    display: block;
    }
    
 .right-header-contentChat .rightside-right-chat p{ 
    background-color: #375e28dc; 
    width:80%;
    margin:0; 
    border-radius: 28px 28px 0 28px;
    color: #fff;
  } 
} 
    </style>
</head>
<body>
                   <header class="top-header" id="myHeader"> 
                                    <div class="top">
                                         <h2>Smart<span>Win</span></h2>
                                         <p>Real Football Predicts</p>
                                    </div> 
                    </header> 
                    <div class="col-lg-12 col-md-12 px-4">
                <div class="cover"></div> 
                <div class="container-fluid carousel">
                        <div class="owl-carousel owl-theme">
                            <div class="row">
                                <div class="col-lg-12 col-md-12"> 
                                <img src="../img/1.jpg" style="filter: blur(3px);-webkit-filter: blur(8px);">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12" align="center"> 
                                <img src="../img/2.jpg" style="filter: blur(8px);-webkit-filter: blur(8px);">
                                </div>
                            </div>  
                            <div class="row">
                                <div class="col-lg-12 col-md-12" align="center"> 
                                <img src="../img/3.jpg" style="filter: blur(8px);-webkit-filter: blur(8px);">
                                </div>
                            </div>  
                        </div>
                </div>
             </div>
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12 side1">
            <div class="statistics">
                        <div class="header-statistics my-4"> 
                        </div>
                        <hr>
                        <?php
                        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                        $total_messages = "select * from users";
                        $run_messages = mysqli_query($link, $total_messages);
                        $total = mysqli_num_rows($run_messages);

                        $online_members = "select * from users where status='Online'";
                        $run_online = mysqli_query($link, $online_members);
                        $sum = mysqli_num_rows($run_online);?>
                                  
             <?php 
                       $selects = "SELECT SUM(total_withdraw) AS sum FROM `withdraw_request` where status='paid'";
                       $pick = mysqli_query( $link, $selects);
                       
     while($row = mysqli_fetch_assoc($pick)){
         $paid= $row['sum'];
     }
                  
                        
                  
                      ?>
                        <?php
                           
                           $date =date("Y-m-d");
                           echo"<div class='text-center text-light'>$date</div>";
                           $today_members = "select * from users where date='$date'";
                        $run_today = mysqli_query($link, $today_members);
                        $today = mysqli_num_rows($run_today);

                        ?>   
                    </div>
            </div>
            <div class="col-md-7 col-sm-12 col-xs-12 main py-4">
                    <div class="text-center">
                        <h1>Login</h1>
                        <p>Don't have an account?</p><a href="register.php" class="btn1">Register</a>
                    </div>
                   <div class="form"align="center">
                   <form action="#" method="post">
                        <div class="row">
                            <div class="col">
                                <input type="email" name="email" id="email" required placeholder="joemikels@gmail.com"><br>
                                <label for="email">Email</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <input type="password" name="password" id="password" required placeholder="password"><br>
                                <label for="password">Password</label>
                            </div>
                        </div> 
                        <div class="g-recaptcha" data-sitekey="6LdyxZsaAAAAAHgT_lEB_3dbYYaK9vfCBIGHAzX5"></div>
                        <div class="row">
                            <div class="col">
                                <button type="submit" name="submit">Login</button>
                            </div> 
                        </div> 
                        <?php include("login_user.php"); ?>
                    </form>
                    <p>Forgotten your password? <a href="../pages/forgotten_pass.php">Reset password</a></p>
                   </div>
            </div> 
        </div>
        <footer class="py-2" style="position:fixed; text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;background:rgb(6, 2, 34);">
                         Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
                        </footer>

        <script>
                // When the user scrolls the page, execute myFunction
            window.onscroll = function() {myFunction()};
            
            // Get the header
            var header = document.getElementById("myHeader");
            
            // Get the offset position of the navbar
            var sticky = header.offsetTop;
            
            // Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
            function myFunction() {
              if (window.pageYOffset > sticky) {
                header.classList.add("sticky");
              } else {
                header.classList.remove("sticky");
              }
            }
        </script>
    
        <!-- jquary files-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <!-- AOS js file -->
    <script src="./aos-master/dist/aos.js"></script> 
    
     <script src="../js/owl.carousel.min.js"></script> 
     <script src="../js/owl.js"></script>
</body>
</html>