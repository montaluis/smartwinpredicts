<?php
    session_start();
    include('../connection/connection.php');

    
if(!isset($_SESSION['email'])){
    header("location: login.php");
}
else {

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- bootstrap link -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../icons/css/all.min.css">

    <!-- Owl carousel --> 
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- AOS link --> 
    <link rel="stylesheet" href="../aos-master/dist/aos.css">

    <!-- main css link -->
    <link rel="stylesheet" href="../css/login.css">

    <title>Smart-win| Mygames</title>

    <style>
       .main {
    overflow-y:scroll;
    background-color:transparent;
    position: relative;
    display: block;
    height:500px;
}
@media only screen and (max-width:500px){
   
   .top-header{
       display:flex;
       box-shadow:0 0 0 rgb(0,0,0);
   }
   
   .top-header h1{
       margin-top:-2rem;
   }
   
    .top-header img{ 
        width:100px;
        height:100px; 
        margin-bottom:-2rem;
        margin-top:-3rem;
        
    } 
    
    .top-header span{
        margin-top:1rem;
        font-size:25px;
        font-weight:500px;
        height:30px;
    }
    
   
.top-header .header{
    position:relative;
    display: flex; 
  }
  
  .win{
      font-size:10px;
  }
  h3{
      font-size:15px;
  }
  .side1{
      display:none;
  }
  .nav{ 
  }
 .user_img h4{  
     margin-top:-2rem;
  }
    .user_img img{
    float:left; 
     width:80px;
     height:80px;
    position: relative;
    margin-top:-2rem;
    margin-left:1rem;
    }
    
     .depo{
        text-align:center;
    }
    
    .user_img{
        margin-top:-2rem;
    } 
    
   .main{
       display: flex;
       flex:flex-wrap;
       position:relative;
       margin-left:-1rem;
       padding:0;
   } 
   .side2{
       display:none;
   }
   .main .plan{
       margin-left:-2rem;
   }
}
    </style>
</head>
<body class="bg-dark">

        <header class="top-header"style="box-shadow: 3px 0px 10px rgba(225,225,225,0.567);">
            <div class="row">
                <div class="col-md-12"align="center">
                    <div class="row">
                        <div class="col-md-3 col-sm-4 col-xs-3" >
                            <div class="web_image"align="center" style="margin-top:5rem;">
                                <img src="../img/images.png" alt="img1" width="150px" height="130px">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-7 col-xs-6 py-2">
                            <h1 class="web_name" style="color:#fff;font-size:50px;font-weight:800;margin-top:1rem !important;"><span>SMART</span><strong style='color:yellow;font-size:30px;font-style:italic;margin-top:1rem;'>WIN</strong></h1>
                            <h3 style="letter-spacing:1rem; color:yellow;">Real Football Predicts</h3>
                            <div class="row nav "align="center" style="background-color:green; margin-top:1rem;padding-bottom:1rem;">
                                <div class="col"><a href="../pages/plan.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'> Payment Plan</a></div>
                                <div class="col"><a href="../pages/how.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>How To Play</a></div>
                                <div class="col"><a href="../pages/rule.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>Rules</a></div>
                                <div class="col"><a href="../pages/contact.php" class='text-light' style='font-weight:600;font-size:15px;padding-bottom:1rem;'>Contact us</a></div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-3"> 
                        <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $user_name = $row['firstname'];
                        $Lastname = $row['lastname'];
                        $sex = $row['status']; 
                        $user_profile = $row['user_pics']; 
                    ?>
                  <div class="user_img d-inline-flex text-light" style="margin-top:3rem;">
                    <div class="right-header-img">
                        <img src="<?php echo "$user_profile";?>" width="100px" height="100px"style="border-radius:50%;border:2px solid green;">
                    </div>
                     <div class="mx-2 my-2">   
                        <h4><strong><?php echo"$user_name $Lastname"?></strong></h4>
                        <div class="row d-flex d-inline-flex">
                            <div class="col-md-5 col-sm-9 d-flex">
                            <p class="text-center" style="margin-right:.5rem;">deposit:  #</p>
                            <h4><strong><?php echo" "?></strong></h4><p id="noti_number2"></p>
                            </div> 
                            <div class="col-md-3">
                            <form action="" method="post">
                            <button name="logout" width="10px" class="btn text-center text-light"><i class="fas fa-door-open"></i></button>

                            <?php
        
                                if(isset($_POST['logout'])){
                                    $update_msg = mysqli_query($link, "UPDATE users SET status='Offline' WHERE email='$user'");
                                    echo"<script>window.open('../pages/login.php', '_self')</script>";
                                    exit();
                                }

                                ?>
                            </form>
                            </div>
                        </div>
                            <div class="chat-flow"> 
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </header>
        <div class="row d-flex main">
            <div class="col-md-3 col-sm-4 col-xs-12">
            <div class="statistics style='opacity:.7;">
                        <div class="header-statistics">
                            <div class="theme">
                                <div class=' mx-2' style='background-color:green;color:white;border-radius:2rem; margin-bottom: 1rem; margin-top: 1rem;padding:.5rem 0;' align='center'>
                                <h3 class='text-center'><strong>Quick Links</strong></h3>
                                <ul class='text-left'style='list-style-type:none;padding-right:1.5rem;'>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../pages/home.php" class="active" style="color:white !important;"><i class="fa fa-user-circle" aria-hidden="true"></i> My Profile</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/personal_info.php" style="color:white !important;"><i class="fa fa-address-book" aria-hidden="true"></i> Personal Info</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/account_setting.php" style="color:white !important;"><i class="fa fa-cogs" aria-hidden="true"></i> Account Setting</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../play/QS.php" style="color:white !important;"><i class="fa fa-futbol" aria-hidden="true"></i> Play</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="#" style="color:white !important;"><i class="fa fa-database" aria-hidden="true"></i> Account History</a></h5></li>
                                    <li style="padding-bottom:.5rem;padding-top:.5rem;border-top:1px solid #ddd"><h5><a href="../links/my_referrals.php" style="color:white !important;"><i class="fa fa-users" aria-hidden="true"></i> My Referrals</a></h5></li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <?php
                        $link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                        $total_messages = "select * from users";
                        $run_messages = mysqli_query($link, $total_messages);
                        $total = mysqli_num_rows($run_messages);

                        $online_members = "select * from users where status='Online'";
                        $run_online = mysqli_query($link, $online_members);
                        $sum = mysqli_num_rows($run_online);?>
                        <?php
                           
                           $date =date("Y-m-d");
                           echo"<div class='text-center text-light'>$date</div>";
                           $today_members = "select * from users where date='$date'";
                        $run_today = mysqli_query($link, $today_members);
                        $today = mysqli_num_rows($run_today);

                        ?>
                        <?php
                        echo "<div class=' mx-2' style='box-shadow:
                        3px 4px 10px rgba(225,225,225,0.567);background-color:green;border-radius:2rem;padding:.5rem 0;' align='center'>
                        <h3 class='text-center text-light'><strong>STATISTICS</strong></h3>
                            <ul class='text-center d-flex'style='list-style-type:none;padding-right:1.5rem; color: yellow;'>
                                <li ><h4>  $total </h4><small>Total Members</small></li>
                                <li ><h4>$today</h4><small>Joined Today</small></li>
                                <li ><h4> $sum </h4><small>Online Members</small></li>
                                <li ><h4>0</h4><small>Total Payments</small></li>
                            </ul>
                        </div>";
                        ?> 
                    </div>
            </div> 
            <div class="col-md-6 bg-light main" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);padding-top:3rem;">
                        <div class="links d-flex mx-5">
                                <p><a href="QS.php" class="mx-2">New games</a></p>
                                <p><a href="mygames.php" style="color: blueviolet;">My games</a></p>
                        </div><br><br><br>
                <div class="my-2 d-block">
                <?php 
                        $user = $_SESSION['email'];
                        $get_user = "select * from users where email='$user'";
                        $run_user = mysqli_query($link, $get_user);
                        $row = mysqli_fetch_array($run_user);

                        $user_id = $row['user_id'];
                        $referral_id = $row['referral_id'];
                        $username = $row['firstname'];
                        $email = $row['email']; 
                        $user_profile = $row['user_pics']; 
                    ?> 
                    <?php echo "<h3 class='text-center my-3'><strong>$username Games</strong></h3>"?>
                    
                    <div class="d-block"> 
                                <div class="d-block" style="padding-left:-2rem;">
                                <div class="row my-2">
                                <ul class="d-flex" style="list-style-type:none;">     
                            <li><div class="col-md-2">
                                <p class=""><strong>Booking Code</strong></p>
                           </div>  </li>
                            <li><div class="col-md-2">
                                <p class=""><strong>Booking Date</strong></p>
                            </div>  </li>
                            <li><div class="col-md-3">
                                <p class=""><strong>Game Code</strong></p>
                            </div>  </li>
                            <li><div class="col-md-2">
                                <p class=""><strong>Status</strong></p>
                            </div> </li> 
                            <li><div class="col-md-1">
                                <p class=""><strong>Stages</strong></p>
                            </div>  </li>
                            </ul>
                        </div> 
                        <div class="row d-flex" align="left">  
                            <div class="col">
                                <p class="">
                                <?php 
                                    $user = $_SESSION['email'];
                                    $get_user = "select * from users where email='$user'";
                                    $run_user = mysqli_query($link, $get_user);
                                    $row = mysqli_fetch_array($run_user);

                                    $user_id = $row['user_id'];
                                    $referral_id = $row['referral_id'];
                                    $username = $row['username'];
                                    $email = $row['email']; 
                                    $user_profile = $row['user_pics'];  
                                    $con = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");
                                        

                                        $user ="SELECT * FROM booking where player_name = '$username' ORDER by 1 ASC";
                                        $run_user = mysqli_query($con, $user);

                                        while ($row_user=mysqli_fetch_array($run_user)) {
                                            
                                            $user_id = $row_user['booking_id']; 
                                            $booking_code = $row_user['booking_code']; 
                                            $date = $row_user['date']; 
                                            $game_code = $row_user['game_code']; 
                                            $status = $row_user['status']; 
                                            $stage = $row_user['stage']; 
                                            $match1 = $row_user['match1']; 
                                            $match2 = $row_user['match2']; 
                                            $match3 = $row_user['match3']; 
                                            $match4 = $row_user['match4']; 
                                            $match5 = $row_user['match5']; 
                                            $match6 = $row_user['match6']; 
                                            $match7 = $row_user['match7']; 
                                            $prediction1 = $row_user['prediction1']; 
                                            $prediction2 = $row_user['prediction2']; 
                                            $prediction3 = $row_user['prediction3']; 
                                            $prediction4 = $row_user['prediction4']; 
                                            $prediction5 = $row_user['prediction5']; 
                                            $prediction6 = $row_user['prediction6']; 
                                            $prediction7 = $row_user['prediction7']; 
                                            ?>
                                            <?php 
                                            echo" 
                                                <li class='d-flex my-2'> 
                                                    <div class='col-md-2 d-flex'> 
                                                    <p style='margin-left:1.7rem;'>$booking_code</p> 
                                                </div>
                                                <div class='col-md-2'>
                                                <p style='margin-left:4rem;'>$date</p>
                                                </div>
                                                <div class='col-md-3'>
                                                <a href='mygames2.php?game_code=$game_code' style='margin-left:5.5rem;'>$game_code</a>
                                                </div>
                                                <div class='col-md-2'>
                                                <p style='margin-left:3.8rem;'>$status</p>
                                                </div>
                                                <div class='col-md-2'>
                                                <form method='post'><button name='stage' style='margin-left:1.3rem;'>$stage</button></form
                                                </div>
                                                </li>  
                                                <li style='border-bottom:1px solid #ddd;list-style-type:none;'>
                                                "; echo"
                                                </li>
                                                ";
                                        }
                                        

                                    ?> 
                                             </p> 
                                         </div> 
                                     </div>
                                </div> 
                    </div>  
                </div>
            </div>
            <div class="col-md-3 col-sm-3 side2">
            <div class="my-2 py-2"align="center" style="box-shadow: 3px 4px 10px rgba(225,225,225,0.567);border-radius:0 2rem;background-color:green;">
            <h1 class="text-light">ScoreBoard</h1>
            <div class="title-box"align="center"style="justify-content:space-between;padding: 0 2rem;">
                <p>Home</p>
                <p id="elapsed"></p>
                <p>Away</p>
            </div>
            <div class="title-box"style="justify-content:space-between;padding: 0 2rem;">
                <div class="team">
                    <img  id="homeLogo" >
                    <p id="homeName"></p>
                </div>
                <p id="goals"style="font-size:15px !important;"></p>
                <div class="team">
                    <img id="awayLogo">
                    <p id="awayName"></p>
                     </div>
                 
            </div> 
            <div id="matchTable" class="matches-table">
          
            </div>
        </div> 
            </div>

            
                      

                        <footer class="bg-dark py-2" style="font-size:14px;position:fixed; text-align:center;bottom:0; justify-content:center;color:#fff;width:100%;">
                         Copyright 2021, All right reserved. Designed by <strong>femzzyblaqlab</strong>
                        </footer>   
                        <script type="text/javascript">
                            function loadDoc() {
                            

                            setInterval(function(){

                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("noti_number").innerHTML = this.responseText;
                                }
                            };
                            xhttp.open("GET", "../links/data.php", true);
                            xhttp.send();

                            },1000);


                            }
                            loadDoc();
                            </script>
                        <script type="text/javascript">
                            function loadDoc() {
                            

                            setInterval(function(){

                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                document.getElementById("noti_number2").innerHTML = this.responseText;
                                }
                            };
                            xhttp.open("GET", "../links/data2.php", true);
                            xhttp.send();

                            },1000);


                            }
                            loadDoc();
                            </script>
        <!-- jquary files-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script src="../icons/js/all.min.js"></script>
    <!-- AOS js file -->
    <script src="../aos-master/dist/aos.js"></script>

    <!-- owl carousel js file --> 
     <script src="../js/owl.carousel.min.js"></script> 
     <script src="../js/main.js"></script> 

</body> 
</html>
<?php }?>
