 <?php
    session_start();
    if(!$_GET["reference"]){
        echo "<script>alert('reference id not found')</script>"; 
        exit;
    }else{
        $reference = $_GET["reference"];
           
        $curl = curl_init();

  

  curl_setopt_array($curl, array(

    CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference) ,

    CURLOPT_RETURNTRANSFER => true,

    CURLOPT_ENCODING => "",

    CURLOPT_MAXREDIRS => 10,

    CURLOPT_TIMEOUT => 30,

    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,

    CURLOPT_CUSTOMREQUEST => "GET",

    CURLOPT_HTTPHEADER => array(

      "Authorization: Bearer sk_live_41370519eee349687089d610923c1acdc60a88ae",

      "Cache-Control: no-cache",

    ),

  ));

  

  $response = curl_exec($curl);

  $err = curl_error($curl);

  curl_close($curl);

  

  if ($err) {

    echo "cURL Error #:" . $err;

  } else {

     //echo $response;
     $result = json_decode($response);

  }
  if($result->data->status  == 'success'){
      
                        
      $status = $result->data->status;
      $reference = $result->data->reference;
      $amount1 = $result->data->amount;
      $lname = $result->data->customer->last_name;
      $fname = $result->data->customer->first_name;  
      $cus_email = $result->data->customer->email;
      date_default_timezone_set('Africa/Lagos');
      $Date_time = date('m/d/Y h:i:s a', time());
       
       include('../connection/connection.php');
                        $get_amount = "select * from users where email='$cus_email'";
                        $run_amount = mysqli_query($link, $get_amount);
                        $row_user = mysqli_fetch_array($run_amount);

                        $id = $row_user['id'];
                        $amount2 = $row_user['deposit'];  
      
        $amount = $amount2 + $amount1 * 0.01; 
      $update_msg = mysqli_query($link, "UPDATE users SET deposit='$amount' WHERE email='$cus_email' ");
      $update_msg2 = mysqli_query($link, "UPDATE users SET total_deposit='$amount' WHERE email='$cus_email' ");
       $sql = "INSERT INTO customer_details (status, reference, fullname, date_purchased, email, amount )
        VALUES ('$status', '$reference', '$lname', '$Date_time', '$cus_email', '$amount ' )";
        if(mysqli_query($link, $sql)){
            echo"<script>alert('Congratulations $lname !, your information submitted successfully')</script>";
            echo"<script>window.open('../pages/home.php', '_self')</script>";
        } else{
            echo"<script>alert('Sorry $fullname!, your information is not correct, try again')</script>";
            echo"<script>window.open('payment.php', '_self')</script>";
        } 
      
  }else{
      echo " error";
  }
    }
    
 ?>