<?php

$link = mysqli_connect("localhost", "u696338378_smart_win", "Sammywendy@234#", "u696338378_smartwindb");

?>