<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    
    <!-- AOS link --> 
    <link rel="stylesheet" href="./aos-master/dist/aos.css">
 

    <title>Smart win| info</title>
 <style>
 @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Roboto:ital@1&display=swap'); 
  *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Poppins', sans-serif;
      
  }
  
  body{ 
      background:black;
      color:white;
      margin:0;
      padding:0;
      box-sizing:border-box;
  }
     .top-header{
         background:rgb(6, 2, 34);
         display:flex; 
         justify-content:space-between;
         width:100vw;
         z-index:1111;
     }  
     .top-header .top{  
         display:block;
     }
     .top-header .top h2{
         color:green;
         padding:.5rem .5rem;
         font-weight:700;
         font-size:25px;
        font-family: 'Poppins', sans-serif;
     }
     .top-header .top span{
         color:yellow;
     }
     
     .top-header .top p{
         color:white;
         padding-left:.5rem;
         position:relative;
         margin-top:-1rem;
     }
     
     .top-header .btn1{ 
         height:6vh;
         width:25vw;
     }
     
     .top-header .btn1 a{
         padding-right:2vw;
         padding-top:1vh;
         padding-bottom:1vh;
         margin-top:3vh;
         margin-right:2vw; 
         border-radius:1.5rem;
         background:transparent;
         border:1px solid green;
         font-weight:600;
         display:flex;
         justify-content:center;
         align-items:center;
         color:white;
         text-align:center;
     }
     
     .top-header .btn1 a:hover{ 
         text-decoration:none;
         background:rgba(0, 128, 0, 0.24);
     }
     
     .main .carousel{  
         margin-top:2vh;
         margin-bottom:2vh; 
         background:black;
         box-shadow:2px 2px 15px rgba(255,255,255, .25);
         border-radius:2rem;
     }
     
     .main .carousel .owl-theme{  
         display:flex; 
         justify-content:center;
         align-items:center;
     }
     
     .main .carousel .owl-theme .web_name{
         color:green;
         text-align:center;
         font-weight:600;
         font-size:40px;
         margin-top:3rem;
     }
     .main .carousel .owl-theme .web_name span{
         color:yellow;
     }
     
     .main .carousel .owl-theme p{ 
         text-align:center;
         position:relative;
         top:-2.7vh;
     }
     
     .main .carousel .owl-theme img{ 
         display:flex;
         align-self:center;
         height:100px;
         width:80px; 
         margin-left:2vw;
     }
     
     
     .side2{ 
         word-wrap: break-word;
     }
     
     .side2 .newsgrid{
        padding:0 !important;
     }
     .side2 .newsgrid a img{
         position:relative;
         min-width:100%;
         max-width:100%;
     }
     
     .side2 .newsgrid a{
         word-wrap: break-word;
         box-shadow:2px 2px 15px rgba(255,255,255, .25);
         margin-bottom:2rem;
         color:white;
         text-align:center; 
         border-radius:5px;
         
     }
     
     .sticky {
      position: fixed;
      top: 0;
      width: 100%
      z-index:1111;
    }
    
    /* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
    .sticky + .content {
      padding-top: 102px;
    }


     @media screen and (max-width: 500px){
    .side2{
        display:none;
    }
    
    .main ul{
        display:flex;
        justify-content:center;
        align-items:center;
        min-width:100%;
    }
    
    .main ul li{ 
        list-style-type:none;
    }
    
    .main ul li h5{
        font-size:11px;
    }
    
    .main ul li p{
        font-size:10px;
    }
}
</style>


</head>
<body>
        <header class="top-header" id="myHeader"> 
                        <div class="top">
                             <h2>Smart<span>Win</span></h2>
                             <p>Real Football Predicts</p>
                        </div>
                        <div class="btn1"> 
                        <a href="./pages/login.php"><i class="fa fa-lock" aria-hidden="true"></i> &nbsp Login  </a>  
                        </div> 
        </header> 
        <div class="d-flex main">  
            <div class="col-lg-8 col-md-12 px-4 main"> 
                     <div class="container carousel">
            <div class="owl-carousel owl-theme">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                    <h1 class="web_name">Smart<span>Win</span></h1> 
                    <p>Real Football Predicts</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12" align="center">
                    <img src="../img/images.png" alt="img1"> 
                    <p>Win easily with your prediction</p>
                    </div>
                </div>  
            </div>
         </div>
                <div> 
                <p><strong>Smart win Predict</strong>, we are here to reward your passion for football and sport betting with ease.With us, you can win up to 2,500,000 Naira for free</p>    
                    <strong> HOW ? </strong><br>
                    <p>Predict outcome of football match(s) of your choice with minimum of 4 odds</p>
                    <i class="fas fa-arrow-right"></i>	You have 9 stages to complete to win the 2,500,000:00 naira at your own choice <br>
                    <i class="fas fa-arrow-right"></i>	You have prize to win at each stage, either your prediction correct or wrong. <br>
                    <i class="fas fa-arrow-right"></i>	You are free to walk away with your prize or continue to the next stage. <br>
                    <i class="fas fa-arrow-right"></i>	You have maxium of 7 games of your choice to predict at each stage <br>
                    <i class="fas fa-arrow-right"></i>	Minimum odd to predict from stage 1-6 is 4 odds <br>
                    <i class="fas fa-arrow-right"></i>	Minimum odd to predict from stage 7-8 is 3.5odds and 3 odds for stage 9 <br>
                    <i class="fas fa-arrow-right"></i>	We offer a token each time you decide to preceed to next stage <br> 
                    <strong> ALL STAGES FOR FREE </strong><br> 
                    </p> 
                    <h3 class="text-center"><strong>Our Payment Plan</strong></h3> 
                     <div class="row my-3" >
                            <ul class="d-flex px-md-4 px-sm-0 plan"> 
                                <li class="mx-2">
                                    <h5><strong>Stage</h5></strong><br>
                                    <p>1</p>
                                    <p>2</p>
                                    <p>3</p>
                                    <p>4</p>
                                    <p>5</p>
                                    <p>6</p>
                                    <p>7</p>
                                    <p>8</p>
                                    <p>9</p>
                                </li>
                                <li class="mx-2">
                                <h5><strong>Odds </h5></strong><br>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>4</p>
                                    <p>3.5</p>
                                    <p>3.5</p>
                                    <p>3</p>
                                </li>
                                <li class="mx-2">
                                <h5><strong>Reward <br>(Win)</strong></h5>
                                    <p>#1,000</p>
                                    <p>#5,000</p>
                                    <p>#12,000</p>
                                    <p>#40,000</p>
                                    <p>#80,000</p>
                                    <p>#200,000</p>
                                    <p>#500,000</p>
                                    <p>#1,000,000</p>
                                    <p>#2,500,000</p>
                                </li>
                                <li class="mx-2">
                                <h5><strong>Reward <br> (Loss)</strong></h5>
                                    <p>#500</p>
                                    <p>#700</p>
                                    <p>#1,000</p>
                                    <p>#1,500</p>
                                    <p>#20,000</p>
                                    <p>#25,000</p>
                                    <p>#50,000</p>
                                    <p>#100,000</p>
                                    <p>#200,000</p>
                                </li> 
                                <li class="mx-2">
                                <h5><strong>Rewards <br> Con't</strong></h5>
                                    <p>#500</p>
                                    <p>#1,000</p>
                                    <p>#1,000</p>
                                    <p>#2,000</p>
                                    <p>#5,000</p>
                                    <p>#5,000</p>
                                    <p>#10,000</p>
                                    <p>#50,000</p>
                                    <p>-</p>
                                </li> 
                                </ul>
                     </div><hr> 
                        <li class="d-flex"><p><strong>Reward Win:</strong>The amount you recieve when you win and want to stop at a stage.</p></li>
                        <li class="d-flex"><p><strong>Reword Loss:</strong>The amount you recieve when you loss at a stage.</p></li>
                        <li class="d-flex"><p><strong>Reword Con't:</strong>The amount you recieve when you and still proceed to next stage.</p></li> 
                      <p><strong>To Qualify </strong><br>  
                      <p>predict 4 odds of your choice and send<br> 500 Naira will be deducted from your account</p>
                      <P><strong>Note:</strong>Once your prediction is correct, you are qualified to play for 2.5M for free.</P>  
                </div>
                </div>
                <div class="col-lg-4 col-md-12 side2">
            <div class="my-2 py-2"align="center">
                    <?php
                        $url = 'https://newsapi.org/v2/top-headlines?country=ng&apiKey=2ead2876b4c540559124e23512d5ffd3';
                        $response = file_get_contents($url);
                        $NewsData = json_decode($response);
                   ?>
                    <header>
                        <h2 class="text-light">Latest News</h2>
                    </header> 
                    <div class="body text-light">
                                <?php
                                    foreach($NewsData->articles as $News){

                                    
                                ?>
                                <div class="row newsgrid"> 
                                          <?php echo "<a href='$News->url'>"?>  
                                          <img src="<?php echo $News->urlToImage ?>" alt="News img">  
                                            <p class="mx-1"><strong>Title: <?php echo $News->title ?></strong></p> 
                                            <p><strong>Description:</strong> <?php echo $News->description ?></p>
                                            <p><strong>Content:</strong> <?php echo $News->content ?></p>
                                            <p><strong>Aurthor:</strong> <?php echo $News->author ?></p>
                                            <p><strong>Published:</strong> <?php echo $News->publishedAt ?></p>
                                            <p><strong>Read More:</strong></p><?php echo"</a>";?> 
                                </div>
                                <?php }?>
                    </div>
                </div> 

        </div 

            </div>
             
     <script>
        // When the user scrolls the page, execute myFunction
    window.onscroll = function() {myFunction()};
    
    // Get the header
    var header = document.getElementById("myHeader");
    
    // Get the offset position of the navbar
    var sticky = header.offsetTop;
    
    // Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
    function myFunction() {
      if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
      } else {
        header.classList.remove("sticky");
      }
    }
</script>

    <!-- jquary files-->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<!-- AOS js file -->
<script src="./aos-master/dist/aos.js"></script>

     <script src="../js/owl.carousel.min.js"></script> 
     <script src="../js/owl.js"></script>
</body>
</html>