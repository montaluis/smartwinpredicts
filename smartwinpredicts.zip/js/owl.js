$(document).ready(function(){

    //owl carousel

$('.owl-carousel').owlCarousel({
    loop:true,
    autoplay: true,
    autoplayTimeout:6000,
    dots:false,
    responsive:{
        0:{
            items: 1
        },
        544:{
            items: 1
        }
    }
})


});